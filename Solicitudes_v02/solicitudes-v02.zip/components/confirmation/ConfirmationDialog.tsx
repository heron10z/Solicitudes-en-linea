"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { AlertCircle } from "lucide-react";

interface ConfirmationDialogProps {
  isOpen: boolean;
  actionType: "accept" | "reject" | "validate";
  folio: string;
  nombre: string;
  estatusActual: string;
  nuevoEstatus: string;
  onConfirm: (reason?: string) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function ConfirmationDialog({
  isOpen,
  actionType,
  folio,
  nombre,
  estatusActual,
  nuevoEstatus,
  onConfirm,
  onCancel,
  isLoading = false,
}: ConfirmationDialogProps) {
  const [rejectionReason, setRejectionReason] = useState("");
  const [reasonError, setReasonError] = useState(false);

  const handleConfirm = () => {
    // Validate rejection reason if rejecting
    if (actionType === "reject" && !rejectionReason.trim()) {
      setReasonError(true);
      return;
    }
    setReasonError(false);
    onConfirm(rejectionReason);
  };

  const getButtonColor = () => {
    if (actionType === "reject") return "bg-red-600 hover:bg-red-700";
    return "bg-primary hover:bg-primary/90";
  };

  const getTitle = () => {
    switch (actionType) {
      case "accept":
        return "Aceptar solicitud";
      case "reject":
        return "Rechazar solicitud";
      case "validate":
        return "Validar solicitud";
      default:
        return "Confirmar acción";
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="mx-4 w-full max-w-lg rounded-lg bg-card p-8 shadow-lg">
        {/* Title */}
        <h2 className="mb-2 text-center text-2xl font-bold text-foreground">
          Confirmar acción
        </h2>

        {/* Subtitle */}
        <p className="mb-6 text-center text-sm text-muted-foreground">
          Estás a punto de cambiar el estatus de la solicitud
        </p>

        {/* Details Section */}
        <div className="mb-6 space-y-4 rounded-lg bg-muted/50 p-5">
          {/* Applicant Name */}
          <div>
            <label className="text-xs font-semibold uppercase text-muted-foreground">
              Nombre del aspirante
            </label>
            <p className="mt-1 text-base font-medium text-foreground">{nombre}</p>
          </div>

          {/* Folio */}
          <div>
            <label className="text-xs font-semibold uppercase text-muted-foreground">
              Folio
            </label>
            <p className="mt-1 text-base font-medium text-foreground">{folio}</p>
          </div>

          {/* Current Status */}
          <div className="flex gap-4">
            <div className="flex-1">
              <label className="text-xs font-semibold uppercase text-muted-foreground">
                Estatus actual
              </label>
              <p className="mt-1 text-base font-medium text-foreground">
                {estatusActual}
              </p>
            </div>

            {/* New Status - Highlighted */}
            <div className="flex-1">
              <label className="text-xs font-semibold uppercase text-muted-foreground">
                Nuevo estatus
              </label>
              <div className="mt-1 inline-block rounded-md bg-primary/10 px-3 py-1">
                <p className="text-base font-bold text-primary">{nuevoEstatus}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Rejection Reason (Conditional) */}
        {actionType === "reject" && (
          <div className="mb-6">
            <label
              htmlFor="rejection-reason"
              className="block text-sm font-semibold text-foreground"
            >
              Motivo de rechazo
            </label>
            <textarea
              id="rejection-reason"
              value={rejectionReason}
              onChange={(e) => {
                setRejectionReason(e.target.value);
                setReasonError(false);
              }}
              placeholder="Describe brevemente la razón..."
              className={`mt-2 w-full rounded-lg border p-3 text-sm font-normal placeholder:text-muted-foreground focus:outline-none focus:ring-2 ${
                reasonError
                  ? "border-red-500 focus:ring-red-500"
                  : "border-border focus:ring-primary"
              }`}
              rows={4}
              disabled={isLoading}
            />
            {reasonError && (
              <p className="mt-2 text-sm text-red-600">
                El motivo de rechazo es obligatorio
              </p>
            )}
          </div>
        )}

        {/* Warning Message */}
        <div className="mb-8 flex gap-3 rounded-lg bg-orange-50 p-4">
          <AlertCircle className="h-5 w-5 flex-shrink-0 text-orange-600" />
          <p className="text-sm text-orange-800">
            Esta acción no se puede deshacer
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button
            variant="outline"
            size="lg"
            onClick={onCancel}
            disabled={isLoading}
            className="flex-1"
          >
            Cancelar
          </Button>
          <Button
            size="lg"
            onClick={handleConfirm}
            disabled={isLoading}
            className={`flex-1 text-white ${getButtonColor()}`}
          >
            {isLoading ? "Procesando..." : "Confirmar"}
          </Button>
        </div>
      </div>
    </div>
  );
}
