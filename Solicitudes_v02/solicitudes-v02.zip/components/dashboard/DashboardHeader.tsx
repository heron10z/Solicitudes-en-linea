import { User } from "lucide-react";

export function DashboardHeader() {
  return (
    <header className="bg-card border-b border-border shadow-sm">
      <div className="max-w-screen-xl mx-auto flex items-center justify-between px-6 py-3">
        {/* Logo + Institution Name */}
        <div className="flex items-center gap-4">
          <div className="flex items-center justify-center w-12 h-12 rounded border border-border bg-muted overflow-hidden">
            {/* Placeholder institutional logo */}
            <svg viewBox="0 0 48 48" className="w-10 h-10" aria-hidden="true">
              <rect width="48" height="48" fill="#6D1F2E" rx="4" />
              <text x="24" y="32" textAnchor="middle" fontSize="20" fontWeight="bold" fill="#fff" fontFamily="sans-serif">
                Zac
              </text>
            </svg>
          </div>
          <div>
            <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-widest leading-none">
              Gobierno del Estado de Zacatecas
            </p>
            <h1 className="text-lg font-bold text-primary leading-tight mt-0.5">
              Gestión de Solicitudes
            </h1>
            <p className="text-[11px] text-muted-foreground leading-none">
              Sistema de Validación de Educadores Comunitarios
            </p>
          </div>
        </div>

        {/* User Profile */}
        <div className="flex items-center gap-2 bg-muted rounded-lg px-3 py-2">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
            <User className="w-4 h-4 text-primary-foreground" aria-hidden="true" />
          </div>
          <div>
            <p className="text-sm font-semibold text-foreground leading-tight">Roberto García</p>
            <p className="text-[11px] text-muted-foreground leading-none">Validador</p>
          </div>
        </div>
      </div>
    </header>
  );
}
