"use client";

import { Search } from "lucide-react";

export type Estatus =
  | "Todos"
  | "En espera"
  | "Notificadas"
  | "Validadas"
  | "Aceptadas"
  | "Rechazadas";

interface FilterSectionProps {
  folio: string;
  nombre: string;
  curp: string;
  estatus: Estatus;
  onFolioChange: (v: string) => void;
  onNombreChange: (v: string) => void;
  onCurpChange: (v: string) => void;
  onEstatusChange: (v: Estatus) => void;
  onSearch: () => void;
}

const estatusOptions: Estatus[] = [
  "Todos",
  "En espera",
  "Notificadas",
  "Validadas",
  "Aceptadas",
  "Rechazadas",
];

export function FilterSection({
  folio,
  nombre,
  curp,
  estatus,
  onFolioChange,
  onNombreChange,
  onCurpChange,
  onEstatusChange,
  onSearch,
}: FilterSectionProps) {
  return (
    <section
      aria-label="Filtros de búsqueda"
      className="bg-card border border-border rounded-lg shadow-sm p-5"
    >
      <h2 className="text-base font-bold text-foreground mb-4">
        Buscar Solicitudes
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
        {/* Folio */}
        <div className="flex flex-col gap-1.5">
          <label
            htmlFor="filter-folio"
            className="text-sm font-semibold text-foreground"
          >
            Folio
          </label>
          <input
            id="filter-folio"
            type="text"
            placeholder="Ej. 2025001234"
            value={folio}
            onChange={(e) => onFolioChange(e.target.value)}
            className="h-10 rounded-md border border-input bg-background px-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        {/* Nombre */}
        <div className="flex flex-col gap-1.5">
          <label
            htmlFor="filter-nombre"
            className="text-sm font-semibold text-foreground"
          >
            Nombre
          </label>
          <input
            id="filter-nombre"
            type="text"
            placeholder="Nombre del aspirante"
            value={nombre}
            onChange={(e) => onNombreChange(e.target.value)}
            className="h-10 rounded-md border border-input bg-background px-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        {/* CURP */}
        <div className="flex flex-col gap-1.5">
          <label
            htmlFor="filter-curp"
            className="text-sm font-semibold text-foreground"
          >
            CURP
          </label>
          <input
            id="filter-curp"
            type="text"
            placeholder="18 caracteres"
            value={curp}
            onChange={(e) => onCurpChange(e.target.value.toUpperCase())}
            maxLength={18}
            className="h-10 rounded-md border border-input bg-background px-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring uppercase"
          />
        </div>

        {/* Estatus + Buscar */}
        <div className="flex gap-3 items-end">
          <div className="flex flex-col gap-1.5 flex-1">
            <label
              htmlFor="filter-estatus"
              className="text-sm font-semibold text-foreground"
            >
              Estatus
            </label>
            <select
              id="filter-estatus"
              value={estatus}
              onChange={(e) => onEstatusChange(e.target.value as Estatus)}
              className="h-10 rounded-md border border-input bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
            >
              {estatusOptions.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
          </div>
          <button
            onClick={onSearch}
            className="h-10 inline-flex items-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
          >
            <Search className="w-4 h-4" aria-hidden="true" />
            Buscar
          </button>
        </div>
      </div>
    </section>
  );
}
