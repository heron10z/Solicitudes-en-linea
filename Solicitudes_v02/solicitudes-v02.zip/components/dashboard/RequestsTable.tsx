"use client";

import Link from "next/link";
import { type Estatus } from "./FilterSection";
import { ArrowRight } from "lucide-react";

export interface Solicitud {
  folio: string;
  nombre: string;
  curp: string;
  municipio: string;
  estatus: Estatus;
  fechaSolicitud: string;
}

interface RequestsTableProps {
  solicitudes: Solicitud[];
}

const statusStyles: Record<
  Estatus,
  { bg: string; text: string; border: string; label: string }
> = {
  Todos: { bg: "", text: "", border: "", label: "" },
  "En espera": {
    bg: "bg-gray-100",
    text: "text-gray-600",
    border: "border-gray-400",
    label: "En espera",
  },
  Notificadas: {
    bg: "bg-[#f5e8ea]",
    text: "text-[#6D1F2E]",
    border: "border-[#6D1F2E]",
    label: "Notificada",
  },
  Validadas: {
    bg: "bg-blue-50",
    text: "text-blue-700",
    border: "border-blue-500",
    label: "Validada",
  },
  Aceptadas: {
    bg: "bg-green-50",
    text: "text-green-700",
    border: "border-green-600",
    label: "Aceptada",
  },
  Rechazadas: {
    bg: "bg-red-50",
    text: "text-red-700",
    border: "border-red-500",
    label: "Rechazada",
  },
};

export function RequestsTable({ solicitudes }: RequestsTableProps) {
  if (solicitudes.length === 0) {
    return (
      <div className="bg-card border border-border rounded-lg shadow-sm p-12 flex flex-col items-center justify-center text-center">
        <p className="text-lg font-semibold text-muted-foreground">
          No se encontraron solicitudes
        </p>
        <p className="text-sm text-muted-foreground mt-1">
          Ajuste los filtros de búsqueda e intente de nuevo.
        </p>
      </div>
    );
  }

  return (
    <section
      aria-label="Tabla de solicitudes"
      className="bg-card border border-border rounded-lg shadow-sm overflow-hidden"
    >
      <div className="overflow-x-auto">
        <table className="w-full text-sm" role="table">
          <thead>
            <tr className="bg-primary text-primary-foreground">
              <th
                scope="col"
                className="px-5 py-4 text-left text-sm font-bold tracking-wide"
              >
                Folio
              </th>
              <th
                scope="col"
                className="px-5 py-4 text-left text-sm font-bold tracking-wide"
              >
                Nombre del Aspirante
              </th>
              <th
                scope="col"
                className="px-5 py-4 text-left text-sm font-bold tracking-wide"
              >
                CURP
              </th>
              <th
                scope="col"
                className="px-5 py-4 text-left text-sm font-bold tracking-wide"
              >
                Municipio
              </th>
              <th
                scope="col"
                className="px-5 py-4 text-left text-sm font-bold tracking-wide"
              >
                Estatus
              </th>
              <th
                scope="col"
                className="px-5 py-4 text-left text-sm font-bold tracking-wide"
              >
                Fecha de Solicitud
              </th>
              <th
                scope="col"
                className="px-5 py-4 text-left text-sm font-bold tracking-wide"
              >
                Acción
              </th>
            </tr>
          </thead>
          <tbody>
            {solicitudes.map((s, idx) => {
              const style = statusStyles[s.estatus];
              return (
                <tr
                  key={s.folio}
                  className={`border-t border-border transition-colors hover:bg-muted/50 ${idx % 2 === 1 ? "bg-muted/20" : "bg-card"}`}
                >
                  <td className="px-5 py-4 font-mono font-semibold text-foreground whitespace-nowrap">
                    {s.folio}
                  </td>
                  <td className="px-5 py-4 text-foreground font-medium">
                    {s.nombre}
                  </td>
                  <td className="px-5 py-4 font-mono text-foreground/80 text-xs">
                    {s.curp}
                  </td>
                  <td className="px-5 py-4 text-foreground/80">{s.municipio}</td>
                  <td className="px-5 py-4">
                    <span
                      className={`inline-block rounded-full border px-3 py-1 text-xs font-bold ${style.bg} ${style.text} ${style.border}`}
                    >
                      {style.label}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-foreground/80 whitespace-nowrap">
                    {s.fechaSolicitud}
                  </td>
                  <td className="px-5 py-4">
                    <Link
                      href={`/detail?folio=${s.folio}`}
                      className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:text-primary/80 hover:underline focus:outline-none focus:ring-2 focus:ring-ring rounded transition-colors"
                    >
                      Revisar detalle
                      <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                    </Link>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="px-5 py-3 border-t border-border bg-muted/30 text-xs text-muted-foreground">
        {solicitudes.length} registro{solicitudes.length !== 1 ? "s" : ""} encontrado{solicitudes.length !== 1 ? "s" : ""}
      </div>
    </section>
  );
}
