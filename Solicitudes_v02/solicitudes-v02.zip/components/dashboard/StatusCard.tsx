"use client";

interface StatusCardProps {
  label: string;
  count: number;
  colorClass: string;
  borderClass: string;
  textClass: string;
  isActive: boolean;
  onClick: () => void;
}

export function StatusCard({
  label,
  count,
  colorClass,
  borderClass,
  textClass,
  isActive,
  onClick,
}: StatusCardProps) {
  return (
    <button
      onClick={onClick}
      className={`flex-1 min-w-[130px] flex flex-col items-center justify-center gap-1 rounded-lg border-2 bg-card px-4 py-5 shadow-sm transition-all hover:shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-ring ${borderClass} ${isActive ? "ring-2 ring-offset-1 " + colorClass.replace("bg-", "ring-") : ""}`}
      aria-pressed={isActive}
      aria-label={`Filtrar por ${label}: ${count} solicitudes`}
    >
      <span className={`text-4xl font-bold leading-none ${textClass}`}>
        {count}
      </span>
      <span className="text-sm font-semibold text-foreground/70 mt-1">{label}</span>
    </button>
  );
}
