"use client";

import { useState, useMemo } from "react";
import { DashboardHeader } from "./DashboardHeader";
import { StatusCard } from "./StatusCard";
import { FilterSection, type Estatus } from "./FilterSection";
import { RequestsTable, type Solicitud } from "./RequestsTable";

// ---------- Sample Data ----------
const ALL_SOLICITUDES: Solicitud[] = [
  {
    folio: "2025001234",
    nombre: "María Elena Rodríguez Pérez",
    curp: "ROPM850312HZSLRR05",
    municipio: "Zacatecas",
    estatus: "En espera",
    fechaSolicitud: "12/01/2025",
  },
  {
    folio: "2025001235",
    nombre: "José Luis Hernández García",
    curp: "HEGL900715HZSRNL09",
    municipio: "Fresnillo",
    estatus: "Notificadas",
    fechaSolicitud: "13/01/2025",
  },
  {
    folio: "2025001236",
    nombre: "Ana Patricia Flores Medina",
    curp: "FOMA921108MZSLDN02",
    municipio: "Guadalupe",
    estatus: "Validadas",
    fechaSolicitud: "14/01/2025",
  },
  {
    folio: "2025001237",
    nombre: "Carlos Alberto Vega Torres",
    curp: "VETC880423HZSGRR01",
    municipio: "Jerez",
    estatus: "Aceptadas",
    fechaSolicitud: "15/01/2025",
  },
  {
    folio: "2025001238",
    nombre: "Laura Beatriz Ramírez Lugo",
    curp: "RALL950630MZSMGR08",
    municipio: "Villanueva",
    estatus: "Rechazadas",
    fechaSolicitud: "16/01/2025",
  },
  {
    folio: "2025001239",
    nombre: "Roberto Jesús Cisneros Mora",
    curp: "CIMR870921HZSSNB03",
    municipio: "Loreto",
    estatus: "En espera",
    fechaSolicitud: "17/01/2025",
  },
  {
    folio: "2025001240",
    nombre: "Silvia Guadalupe Muñoz Castro",
    curp: "MUCS910314MZSNSL04",
    municipio: "Ojocaliente",
    estatus: "Notificadas",
    fechaSolicitud: "18/01/2025",
  },
  {
    folio: "2026001241",
    nombre: "Fernando Alonso Nieto Ruiz",
    curp: "NIRF001205HZSTZR07",
    municipio: "Calera",
    estatus: "Validadas",
    fechaSolicitud: "03/02/2026",
  },
  {
    folio: "2026001242",
    nombre: "Daniela Sofía Lara Espinoza",
    curp: "LAED030810MZSSPN06",
    municipio: "Pánuco",
    estatus: "Aceptadas",
    fechaSolicitud: "04/02/2026",
  },
  {
    folio: "2026001243",
    nombre: "Martín Ezequiel Sandoval Díaz",
    curp: "SADM980615HZSNDZ02",
    municipio: "Monte Escobedo",
    estatus: "Rechazadas",
    fechaSolicitud: "05/02/2026",
  },
];

const CARD_CONFIGS: {
  label: string;
  estatus: Estatus;
  borderClass: string;
  textClass: string;
  colorClass: string;
}[] = [
  {
    label: "En espera",
    estatus: "En espera",
    borderClass: "border-gray-400",
    textClass: "text-gray-600",
    colorClass: "bg-gray-400",
  },
  {
    label: "Notificadas",
    estatus: "Notificadas",
    borderClass: "border-[#6D1F2E]",
    textClass: "text-[#6D1F2E]",
    colorClass: "bg-[#6D1F2E]",
  },
  {
    label: "Validadas",
    estatus: "Validadas",
    borderClass: "border-blue-500",
    textClass: "text-blue-700",
    colorClass: "bg-blue-500",
  },
  {
    label: "Aceptadas",
    estatus: "Aceptadas",
    borderClass: "border-green-600",
    textClass: "text-green-700",
    colorClass: "bg-green-600",
  },
  {
    label: "Rechazadas",
    estatus: "Rechazadas",
    borderClass: "border-red-500",
    textClass: "text-red-700",
    colorClass: "bg-red-500",
  },
];

export function Dashboard() {
  const [cicloEscolar, setCicloEscolar] = useState("2025-2026");
  const [filterFolio, setFilterFolio] = useState("");
  const [filterNombre, setFilterNombre] = useState("");
  const [filterCurp, setFilterCurp] = useState("");
  const [filterEstatus, setFilterEstatus] = useState<Estatus>("Todos");
  const [activeCard, setActiveCard] = useState<Estatus | null>(null);
  const [appliedFilters, setAppliedFilters] = useState({
    folio: "",
    nombre: "",
    curp: "",
    estatus: "Todos" as Estatus,
    card: null as Estatus | null,
  });
  const [revisingFolio, setRevisingFolio] = useState<string | null>(null);

  const counts = useMemo(
    () => ({
      "En espera": ALL_SOLICITUDES.filter((s) => s.estatus === "En espera").length,
      Notificadas: ALL_SOLICITUDES.filter((s) => s.estatus === "Notificadas").length,
      Validadas: ALL_SOLICITUDES.filter((s) => s.estatus === "Validadas").length,
      Aceptadas: ALL_SOLICITUDES.filter((s) => s.estatus === "Aceptadas").length,
      Rechazadas: ALL_SOLICITUDES.filter((s) => s.estatus === "Rechazadas").length,
    }),
    []
  );

  const filteredSolicitudes = useMemo(() => {
    return ALL_SOLICITUDES.filter((s) => {
      const byCard =
        appliedFilters.card ? s.estatus === appliedFilters.card : true;
      const byFolio = appliedFilters.folio
        ? s.folio.includes(appliedFilters.folio)
        : true;
      const byNombre = appliedFilters.nombre
        ? s.nombre.toLowerCase().includes(appliedFilters.nombre.toLowerCase())
        : true;
      const byCurp = appliedFilters.curp
        ? s.curp.includes(appliedFilters.curp.toUpperCase())
        : true;
      const byEstatus =
        appliedFilters.estatus !== "Todos"
          ? s.estatus === appliedFilters.estatus
          : true;
      return byCard && byFolio && byNombre && byCurp && byEstatus;
    });
  }, [appliedFilters]);

  const handleCardClick = (estatus: Estatus) => {
    const next = activeCard === estatus ? null : estatus;
    setActiveCard(next);
    setAppliedFilters((prev) => ({ ...prev, card: next }));
  };

  const handleSearch = () => {
    setActiveCard(null);
    setAppliedFilters({
      folio: filterFolio,
      nombre: filterNombre,
      curp: filterCurp,
      estatus: filterEstatus,
      card: null,
    });
  };

  const handleRevisar = (folio: string) => {
    setRevisingFolio(folio);
  };

  if (revisingFolio) {
    const solicitud = ALL_SOLICITUDES.find((s) => s.folio === revisingFolio);
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <DashboardHeader />
        <main className="flex-1 max-w-screen-xl mx-auto w-full px-6 py-8">
          <button
            onClick={() => setRevisingFolio(null)}
            className="mb-6 inline-flex items-center gap-2 text-sm font-semibold text-primary hover:text-primary/80 hover:underline focus:outline-none"
          >
            ← Volver al listado
          </button>
          <div className="bg-card border border-border rounded-lg shadow-sm p-8 max-w-2xl">
            <h2 className="text-xl font-bold text-primary mb-6">
              Detalle de Solicitud
            </h2>
            {solicitud && (
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {[
                  { label: "Folio", value: solicitud.folio },
                  { label: "Nombre del Aspirante", value: solicitud.nombre },
                  { label: "CURP", value: solicitud.curp },
                  { label: "Municipio", value: solicitud.municipio },
                  { label: "Estatus", value: solicitud.estatus },
                  { label: "Fecha de Solicitud", value: solicitud.fechaSolicitud },
                ].map(({ label, value }) => (
                  <div key={label} className="flex flex-col gap-1">
                    <dt className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
                      {label}
                    </dt>
                    <dd className="text-base font-semibold text-foreground">{value}</dd>
                  </div>
                ))}
              </dl>
            )}
            <div className="mt-8 flex gap-3 flex-wrap">
              <button className="rounded-md bg-green-600 px-6 py-2 text-sm font-bold text-white hover:bg-green-700 transition-colors focus:outline-none focus:ring-2 focus:ring-green-500">
                Aceptar
              </button>
              <button className="rounded-md bg-red-600 px-6 py-2 text-sm font-bold text-white hover:bg-red-700 transition-colors focus:outline-none focus:ring-2 focus:ring-red-500">
                Rechazar
              </button>
              <button
                onClick={() => setRevisingFolio(null)}
                className="rounded-md border border-border bg-muted px-6 py-2 text-sm font-bold text-foreground hover:bg-muted/80 transition-colors focus:outline-none focus:ring-2 focus:ring-ring"
              >
                Cancelar
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <DashboardHeader />

      <main className="flex-1 max-w-screen-xl mx-auto w-full px-6 py-6 flex flex-col gap-5">
        {/* State + Ciclo Escolar bar */}
        <div className="flex flex-wrap items-center gap-4 bg-card border border-border rounded-lg px-5 py-3 shadow-sm">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
              Estado:
            </span>
            <span className="text-sm font-bold text-primary bg-primary/10 rounded px-2 py-0.5">
              Zacatecas
            </span>
          </div>
          <div className="w-px h-5 bg-border hidden sm:block" />
          <div className="flex items-center gap-2">
            <label
              htmlFor="ciclo-escolar"
              className="text-xs font-bold text-muted-foreground uppercase tracking-wider whitespace-nowrap"
            >
              Ciclo Escolar:
            </label>
            <select
              id="ciclo-escolar"
              value={cicloEscolar}
              onChange={(e) => setCicloEscolar(e.target.value)}
              className="h-8 rounded border border-input bg-background px-2 text-sm font-semibold text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="2024-2025">2024-2025</option>
              <option value="2025-2026">2025-2026</option>
              <option value="2026-2027">2026-2027</option>
            </select>
          </div>
        </div>

        {/* Status Summary Cards */}
        <section aria-label="Resumen de solicitudes por estatus">
          <h2 className="sr-only">Resumen de solicitudes</h2>
          <div className="flex flex-wrap gap-4">
            {CARD_CONFIGS.map((cfg) => (
              <StatusCard
                key={cfg.estatus}
                label={cfg.label}
                count={counts[cfg.estatus]}
                colorClass={cfg.colorClass}
                borderClass={cfg.borderClass}
                textClass={cfg.textClass}
                isActive={activeCard === cfg.estatus}
                onClick={() => handleCardClick(cfg.estatus)}
              />
            ))}
          </div>
        </section>

        {/* Filters */}
        <FilterSection
          folio={filterFolio}
          nombre={filterNombre}
          curp={filterCurp}
          estatus={filterEstatus}
          onFolioChange={setFilterFolio}
          onNombreChange={setFilterNombre}
          onCurpChange={setFilterCurp}
          onEstatusChange={setFilterEstatus}
          onSearch={handleSearch}
        />

        {/* Requests Table */}
        <RequestsTable
          solicitudes={filteredSolicitudes}
          onRevisar={handleRevisar}
        />
      </main>
    </div>
  );
}
