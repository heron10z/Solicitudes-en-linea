import { Badge } from "@/components/ui/badge";

interface DocumentReviewHeaderProps {
  folio: string;
  nombre: string;
}

export function DocumentReviewHeader({ folio, nombre }: DocumentReviewHeaderProps) {
  return (
    <div className="border-b border-border bg-card p-6">
      {/* Breadcrumb */}
      <div className="mb-6 text-sm text-muted-foreground">
        <span>Gestión de Solicitudes</span>
        <span className="mx-2">/</span>
        <span>Detalle</span>
        <span className="mx-2">/</span>
        <span className="text-foreground font-semibold">Documentos</span>
      </div>

      {/* Title and Folio */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            Revisión de Documentos
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {nombre} • Folio: <span className="font-mono font-semibold">{folio}</span>
          </p>
        </div>
      </div>
    </div>
  );
}
