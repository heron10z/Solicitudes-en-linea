"use client";

import { useState } from "react";
import { ZoomIn, ZoomOut } from "lucide-react";

interface DocumentViewerProps {
  documento: {
    id: string;
    nombre: string;
    fechaCarga: string;
  };
}

export function DocumentViewer({ documento }: DocumentViewerProps) {
  const [zoom, setZoom] = useState(100);

  const handleZoomIn = () => setZoom((prev) => Math.min(prev + 25, 200));
  const handleZoomOut = () => setZoom((prev) => Math.max(prev - 25, 50));
  const handleReset = () => setZoom(100);

  return (
    <div className="flex flex-col h-full bg-card rounded-lg border border-border">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-border gap-4">
        <div className="flex items-center gap-2">
          <button
            onClick={handleZoomOut}
            disabled={zoom <= 50}
            className="p-2 rounded-lg border border-border hover:bg-muted disabled:opacity-50 disabled:cursor-not-allowed transition-colors focus:outline-none focus:ring-2 focus:ring-ring"
            aria-label="Zoom out"
          >
            <ZoomOut className="w-5 h-5 text-foreground" />
          </button>

          <span className="text-sm font-medium text-foreground min-w-12 text-center">
            {zoom}%
          </span>

          <button
            onClick={handleZoomIn}
            disabled={zoom >= 200}
            className="p-2 rounded-lg border border-border hover:bg-muted disabled:opacity-50 disabled:cursor-not-allowed transition-colors focus:outline-none focus:ring-2 focus:ring-ring"
            aria-label="Zoom in"
          >
            <ZoomIn className="w-5 h-5 text-foreground" />
          </button>

          <div className="w-px h-6 bg-border mx-2" />

          <button
            onClick={handleReset}
            className="px-3 py-2 text-sm font-medium rounded-lg border border-border hover:bg-muted transition-colors focus:outline-none focus:ring-2 focus:ring-ring"
          >
            Restablecer
          </button>
        </div>
      </div>

      {/* Viewer Area */}
      <div className="flex-1 overflow-auto bg-muted p-6 flex items-center justify-center">
        <div
          className="bg-white rounded-lg shadow-lg transition-transform duration-200"
          style={{ transform: `scale(${zoom / 100})` }}
        >
          {/* Placeholder for PDF/Image preview */}
          <div
            className="bg-white border border-border rounded-lg flex items-center justify-center"
            style={{
              width: "600px",
              height: "800px",
            }}
          >
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">
                Visualización del documento
              </p>
              <p className="text-xs text-muted-foreground">
                (En una aplicación real, aquí iría el PDF/imagen)
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Document Info */}
      <div className="px-6 py-4 border-t border-border bg-card">
        <p className="text-xs text-muted-foreground mb-1">
          Nombre del documento
        </p>
        <p className="text-sm font-semibold text-foreground mb-3">
          {documento.nombre}
        </p>
        <p className="text-xs text-muted-foreground">
          Fecha de carga: <span className="font-medium">{documento.fechaCarga}</span>
        </p>
      </div>
    </div>
  );
}
