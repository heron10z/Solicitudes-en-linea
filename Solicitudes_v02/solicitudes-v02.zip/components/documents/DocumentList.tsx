"use client";

import { Badge } from "@/components/ui/badge";

export type DocumentStatus = "Validado" | "Pendiente" | "Rechazado";

interface Document {
  id: string;
  nombre: string;
  status: DocumentStatus;
}

interface DocumentListProps {
  documents: Document[];
  selectedId: string;
  onSelect: (id: string) => void;
}

const statusColors = {
  Validado: "bg-status-validated/10 text-status-validated border-status-validated",
  Pendiente: "bg-status-waiting/10 text-status-waiting border-status-waiting",
  Rechazado: "bg-destructive/10 text-destructive border-destructive",
};

export function DocumentList({ documents, selectedId, onSelect }: DocumentListProps) {
  return (
    <div className="flex flex-col h-full">
      <p className="text-sm font-semibold text-foreground mb-4 px-4 pt-4">
        Documentos
      </p>
      <div className="flex-1 overflow-y-auto space-y-2 px-4 pb-4">
        {documents.map((doc) => (
          <button
            key={doc.id}
            onClick={() => onSelect(doc.id)}
            className={`w-full text-left p-4 rounded-lg border-2 transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-ring ${
              selectedId === doc.id
                ? "bg-primary/5 border-primary shadow-md"
                : "bg-card border-border hover:bg-muted"
            }`}
          >
            <p className="text-sm font-semibold text-foreground mb-2 leading-tight">
              {doc.nombre}
            </p>
            <Badge
              variant="outline"
              className={`text-xs font-medium border ${statusColors[doc.status]}`}
            >
              {doc.status}
            </Badge>
          </button>
        ))}
      </div>
    </div>
  );
}
