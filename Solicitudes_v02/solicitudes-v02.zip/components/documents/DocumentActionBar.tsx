"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

interface DocumentActionBarProps {
  onCorrect: () => void;
  onIncorrect: () => void;
  folio: string;
  isProcessing?: boolean;
}

export function DocumentActionBar({
  onCorrect,
  onIncorrect,
  folio,
  isProcessing = false,
}: DocumentActionBarProps) {
  return (
    <div className="border-t border-border bg-card p-6 flex items-center justify-between gap-4">
      <Link
        href={`/detail?folio=${folio}`}
        className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg border border-border hover:bg-muted transition-colors focus:outline-none focus:ring-2 focus:ring-ring"
      >
        <ArrowLeft className="w-4 h-4" />
        Volver al detalle
      </Link>

      <div className="flex items-center gap-3">
        <button
          onClick={onIncorrect}
          disabled={isProcessing}
          className="px-4 py-2 text-sm font-semibold rounded-lg border-2 border-destructive text-destructive hover:bg-destructive/5 disabled:opacity-50 disabled:cursor-not-allowed transition-colors focus:outline-none focus:ring-2 focus:ring-ring"
        >
          Marcar como incorrecto
        </button>

        <button
          onClick={onCorrect}
          disabled={isProcessing}
          className="px-6 py-2 text-sm font-semibold rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
        >
          {isProcessing ? "Procesando..." : "Documento correcto"}
        </button>
      </div>
    </div>
  );
}
