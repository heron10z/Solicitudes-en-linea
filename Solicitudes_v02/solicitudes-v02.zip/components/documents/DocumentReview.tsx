"use client";

import { useState } from "react";
import { DocumentReviewHeader } from "./DocumentReviewHeader";
import { DocumentList, type DocumentStatus } from "./DocumentList";
import { DocumentViewer } from "./DocumentViewer";
import { DocumentActionBar } from "./DocumentActionBar";

interface Document {
  id: string;
  nombre: string;
  status: DocumentStatus;
  fechaCarga: string;
}

interface DocumentReviewProps {
  folio: string;
  nombre: string;
  documentos?: Document[];
}

// Sample documents for demo
const SAMPLE_DOCUMENTS: Document[] = [
  {
    id: "1",
    nombre: "INE",
    status: "Pendiente",
    fechaCarga: "12/01/2025 09:15",
  },
  {
    id: "2",
    nombre: "CURP",
    status: "Validado",
    fechaCarga: "12/01/2025 09:20",
  },
  {
    id: "3",
    nombre: "Comprobante de domicilio",
    status: "Pendiente",
    fechaCarga: "12/01/2025 09:25",
  },
  {
    id: "4",
    nombre: "Certificados",
    status: "Rechazado",
    fechaCarga: "12/01/2025 09:30",
  },
];

export function DocumentReview({
  folio,
  nombre,
  documentos = SAMPLE_DOCUMENTS,
}: DocumentReviewProps) {
  const [selectedDocId, setSelectedDocId] = useState(documentos[0]?.id || "1");
  const [isProcessing, setIsProcessing] = useState(false);

  const selectedDoc = documentos.find((d) => d.id === selectedDocId);

  const handleCorrect = async () => {
    setIsProcessing(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    console.log("[v0] Document marked as correct:", selectedDocId);
    setIsProcessing(false);
  };

  const handleIncorrect = async () => {
    setIsProcessing(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    console.log("[v0] Document marked as incorrect:", selectedDocId);
    setIsProcessing(false);
  };

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Header */}
      <DocumentReviewHeader folio={folio} nombre={nombre} />

      {/* Main Content - Split View */}
      <div className="flex flex-1 overflow-hidden gap-6 p-6">
        {/* Left Panel - Document List */}
        <div className="w-64 flex-shrink-0 bg-card rounded-lg border border-border overflow-hidden flex flex-col">
          <DocumentList
            documents={documentos}
            selectedId={selectedDocId}
            onSelect={setSelectedDocId}
          />
        </div>

        {/* Right Panel - Document Viewer */}
        <div className="flex-1 flex flex-col min-w-0">
          {selectedDoc && (
            <DocumentViewer documento={selectedDoc} />
          )}
        </div>
      </div>

      {/* Action Bar */}
      {selectedDoc && (
        <DocumentActionBar
          onCorrect={handleCorrect}
          onIncorrect={handleIncorrect}
          folio={folio}
          isProcessing={isProcessing}
        />
      )}
    </div>
  );
}
