import { Button } from "@/components/ui/button";

interface AvailableActionsProps {
  estatus: string;
  onValidar?: () => void;
  onRechazar?: () => void;
  onAceptar?: () => void;
  onNotificar?: () => void;
}

export function AvailableActions({
  estatus,
  onValidar,
  onRechazar,
  onAceptar,
  onNotificar,
}: AvailableActionsProps) {
  // Define actions based on status
  const getActionsForStatus = (status: string) => {
    switch (status) {
      case "En espera":
        return [
          { label: "Validar", action: onValidar, variant: "default" as const },
          { label: "Rechazar", action: onRechazar, variant: "outline" as const },
        ];
      case "Validadas":
        return [
          { label: "Aceptar", action: onAceptar, variant: "default" as const },
          { label: "Rechazar", action: onRechazar, variant: "outline" as const },
        ];
      case "Notificadas":
        return [];
      case "Aceptadas":
        return [];
      case "Rechazadas":
        return [];
      default:
        return [];
    }
  };

  const actions = getActionsForStatus(estatus);

  if (actions.length === 0) {
    return (
      <div className="border-t border-border bg-card p-6">
        <h2 className="mb-4 text-lg font-bold text-foreground">
          Acciones disponibles
        </h2>
        <p className="text-sm text-muted-foreground">
          No hay acciones disponibles para este estado.
        </p>
      </div>
    );
  }

  return (
    <div className="border-t border-border bg-card p-6">
      <h2 className="mb-6 text-lg font-bold text-foreground">
        Acciones disponibles
      </h2>

      <div className="flex gap-3">
        {actions.map((action) => (
          <Button
            key={action.label}
            variant={action.variant}
            size="lg"
            onClick={action.action}
            className={
              action.variant === "default"
                ? "bg-primary hover:bg-primary/90"
                : "border-red-200 text-red-700 hover:bg-red-50"
            }
          >
            {action.label}
          </Button>
        ))}
      </div>
    </div>
  );
}
