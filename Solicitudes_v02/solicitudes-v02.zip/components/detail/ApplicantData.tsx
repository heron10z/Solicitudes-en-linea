interface ApplicantDataProps {
  nombre: string;
  curp: string;
  municipio: string;
  telefono: string;
  correo: string;
}

export function ApplicantData({
  nombre,
  curp,
  municipio,
  telefono,
  correo,
}: ApplicantDataProps) {
  return (
    <div className="border-t border-border bg-card p-6">
      <h2 className="mb-6 text-lg font-bold text-foreground">
        Datos del Aspirante
      </h2>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
        {/* Column 1 */}
        <div className="space-y-6">
          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Nombre completo
            </label>
            <p className="mt-2 text-sm font-medium text-foreground">
              {nombre}
            </p>
          </div>

          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              CURP
            </label>
            <p className="mt-2 font-mono text-sm font-medium text-foreground">
              {curp}
            </p>
          </div>
        </div>

        {/* Column 2 */}
        <div className="space-y-6">
          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Municipio
            </label>
            <p className="mt-2 text-sm font-medium text-foreground">
              {municipio}
            </p>
          </div>

          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Teléfono
            </label>
            <p className="mt-2 text-sm font-medium text-foreground">
              {telefono}
            </p>
          </div>
        </div>
      </div>

      {/* Full width email */}
      <div className="mt-6 border-t border-border pt-6">
        <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Correo electrónico
        </label>
        <p className="mt-2 text-sm font-medium text-foreground">
          {correo}
        </p>
      </div>
    </div>
  );
}
