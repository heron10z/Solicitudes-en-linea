import { Badge } from "@/components/ui/badge";

interface DetailHeaderProps {
  folio: string;
  nombre: string;
}

export function DetailHeader({ folio, nombre }: DetailHeaderProps) {
  return (
    <div className="border-b border-border bg-card p-6">
      {/* Breadcrumb */}
      <div className="mb-6 text-sm text-muted-foreground">
        <span>Gestión de Solicitudes</span>
        <span className="mx-2">/</span>
        <span>Detalle de Solicitud</span>
      </div>

      {/* Title and Folio */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            {nombre}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Folio: <span className="font-mono font-semibold">{folio}</span>
          </p>
        </div>
      </div>
    </div>
  );
}
