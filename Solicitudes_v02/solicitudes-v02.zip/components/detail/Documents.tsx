import Link from "next/link";
import { Button } from "@/components/ui/button";
import { FileText } from "lucide-react";

interface Document {
  id: string;
  nombre: string;
  estado: "Cargado" | "Pendiente";
}

interface DocumentsProps {
  documentos: Document[];
  folio?: string;
}

export function Documents({ documentos, folio = "2025001234" }: DocumentsProps) {
  return (
    <div className="border-t border-border bg-card p-6">
      <h2 className="mb-6 text-lg font-bold text-foreground">
        Documentos
      </h2>

      <div className="space-y-3">
        {documentos.map((doc) => (
          <div
            key={doc.id}
            className="flex items-center justify-between rounded-md border border-border p-4"
          >
            <div className="flex items-center gap-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-muted">
                <FileText className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="font-medium text-foreground">
                  {doc.nombre}
                </p>
                <p className="text-xs text-muted-foreground">
                  Estado: <span className="font-semibold">{doc.estado}</span>
                </p>
              </div>
            </div>

            {doc.estado === "Cargado" && (
              <Link
                href={`/documents?folio=${folio}`}
                className="inline-flex items-center justify-center whitespace-nowrap rounded-md border border-primary bg-background px-3 py-2 text-sm font-medium text-primary hover:bg-primary/5 focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
              >
                Ver documento
              </Link>
            )}

            {doc.estado === "Pendiente" && (
              <span className="text-xs font-medium text-muted-foreground">
                Pendiente
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
