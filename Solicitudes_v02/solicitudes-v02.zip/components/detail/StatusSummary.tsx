import { Badge } from "@/components/ui/badge";

interface StatusSummaryProps {
  estatus: string;
  fechaSolicitud: string;
  ultimaActualizacion: string;
}

const statusConfig: Record<string, { bg: string; text: string }> = {
  "En espera": { bg: "bg-slate-100", text: "text-slate-700" },
  Notificadas: { bg: "bg-primary/10", text: "text-primary" },
  Validadas: { bg: "bg-blue-50", text: "text-blue-700" },
  Aceptadas: { bg: "bg-green-50", text: "text-green-700" },
  Rechazadas: { bg: "bg-red-50", text: "text-red-700" },
};

export function StatusSummary({
  estatus,
  fechaSolicitud,
  ultimaActualizacion,
}: StatusSummaryProps) {
  const config = statusConfig[estatus] || statusConfig["En espera"];

  return (
    <div className={`p-6 ${config.bg}`}>
      <div className="space-y-4">
        {/* Status Badge */}
        <div>
          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Estado actual
          </p>
          <p className={`text-lg font-bold ${config.text}`}>
            {estatus}
          </p>
        </div>

        {/* Dates */}
        <div className="grid grid-cols-2 gap-4 pt-2">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Fecha de solicitud
            </p>
            <p className="mt-1 text-sm font-medium text-foreground">
              {fechaSolicitud}
            </p>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Última actualización
            </p>
            <p className="mt-1 text-sm font-medium text-foreground">
              {ultimaActualizacion}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
