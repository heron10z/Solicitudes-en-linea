"use client";

import { useState } from "react";
import { DetailHeader } from "./DetailHeader";
import { StatusSummary } from "./StatusSummary";
import { ApplicantData } from "./ApplicantData";
import { Documents } from "./Documents";
import { AvailableActions } from "./AvailableActions";
import { HistorialAcciones } from "./HistorialAcciones";
import { ConfirmationDialog } from "@/components/confirmation/ConfirmationDialog";

// Sample applicant data (in a real app, this would come from the URL or API)
interface SolicitudDetail {
  folio: string;
  nombre: string;
  curp: string;
  municipio: string;
  telefono: string;
  correo: string;
  estatus: string;
  fechaSolicitud: string;
  ultimaActualizacion: string;
  documentos: Array<{
    id: string;
    nombre: string;
    estado: "Cargado" | "Pendiente";
  }>;
  historial: Array<{
    fecha: string;
    accion: string;
    usuario: string;
  }>;
}

// Sample data
const SAMPLE_SOLICITUD: SolicitudDetail = {
  folio: "2025001234",
  nombre: "María Elena Rodríguez Pérez",
  curp: "ROPM850312HZSLRR05",
  municipio: "Zacatecas",
  telefono: "+52 492 123 4567",
  correo: "maria.rodriguez@email.com",
  estatus: "En espera",
  fechaSolicitud: "12/01/2025",
  ultimaActualizacion: "12/01/2025 10:30",
  documentos: [
    { id: "1", nombre: "Cédula de identificación oficial", estado: "Cargado" },
    { id: "2", nombre: "Comprobante de domicilio", estado: "Cargado" },
    { id: "3", nombre: "Certificado de estudios", estado: "Cargado" },
    { id: "4", nombre: "Carta de recomendación", estado: "Pendiente" },
  ],
  historial: [
    {
      fecha: "12/01/2025 10:30",
      accion: "Solicitud enviada",
      usuario: "Sistema",
    },
    {
      fecha: "12/01/2025 10:35",
      accion: "Documentos recibidos",
      usuario: "Sistema",
    },
  ],
};

export function RequestDetail() {
  const [solicitud, setSolicitud] = useState<SolicitudDetail>(SAMPLE_SOLICITUD);
  const [actionLoading, setActionLoading] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    actionType: "accept" | "reject" | "validate" | null;
  }>({ isOpen: false, actionType: null });

  const handleValidar = () => {
    setConfirmDialog({ isOpen: true, actionType: "validate" });
  };

  const handleRechazar = () => {
    setConfirmDialog({ isOpen: true, actionType: "reject" });
  };

  const handleAceptar = () => {
    setConfirmDialog({ isOpen: true, actionType: "accept" });
  };

  const handleConfirmAction = (reason?: string) => {
    setActionLoading(true);
    const actionType = confirmDialog.actionType;

    // Simulate API call
    setTimeout(() => {
      let newStatus = solicitud.estatus;
      let actionMessage = "";

      switch (actionType) {
        case "validate":
          newStatus = "Validadas";
          actionMessage = "Solicitud validada";
          break;
        case "accept":
          newStatus = "Aceptadas";
          actionMessage = "Solicitud aceptada";
          break;
        case "reject":
          newStatus = "Rechazadas";
          actionMessage = reason
            ? `Solicitud rechazada: ${reason}`
            : "Solicitud rechazada";
          break;
      }

      setSolicitud((prev) => ({
        ...prev,
        estatus: newStatus,
        ultimaActualizacion: new Date().toLocaleString("es-MX"),
        historial: [
          {
            fecha: new Date().toLocaleString("es-MX"),
            accion: actionMessage,
            usuario: "Roberto García",
          },
          ...prev.historial,
        ],
      }));

      setActionLoading(false);
      setConfirmDialog({ isOpen: false, actionType: null });
    }, 1000);
  };

  const getStatusMap = (status: string) => {
    switch (status) {
      case "En espera":
        return "Validadas";
      case "Validadas":
        return "Aceptadas";
      case "Notificadas":
        return status;
      case "Aceptadas":
        return status;
      case "Rechazadas":
        return status;
      default:
        return status;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <DetailHeader folio={solicitud.folio} nombre={solicitud.nombre} />

      <div className="mx-auto max-w-4xl">
        {/* Status and Summary */}
        <StatusSummary
          estatus={solicitud.estatus}
          fechaSolicitud={solicitud.fechaSolicitud}
          ultimaActualizacion={solicitud.ultimaActualizacion}
        />

        {/* Applicant Data */}
        <ApplicantData
          nombre={solicitud.nombre}
          curp={solicitud.curp}
          municipio={solicitud.municipio}
          telefono={solicitud.telefono}
          correo={solicitud.correo}
        />

        {/* Documents */}
        <Documents documentos={solicitud.documentos} />

        {/* Available Actions */}
        <AvailableActions
          estatus={solicitud.estatus}
          onValidar={handleValidar}
          onRechazar={handleRechazar}
          onAceptar={handleAceptar}
        />

        {/* Historial */}
        <HistorialAcciones entries={solicitud.historial} />
      </div>

      {/* Confirmation Dialog */}
      <ConfirmationDialog
        isOpen={confirmDialog.isOpen}
        actionType={confirmDialog.actionType || "validate"}
        folio={solicitud.folio}
        nombre={solicitud.nombre}
        estatusActual={solicitud.estatus}
        nuevoEstatus={getStatusMap(solicitud.estatus)}
        onConfirm={handleConfirmAction}
        onCancel={() =>
          setConfirmDialog({ isOpen: false, actionType: null })
        }
        isLoading={actionLoading}
      />
    </div>
  );
}
