interface HistorialEntry {
  fecha: string;
  accion: string;
  usuario: string;
}

interface HistorialAccionesProps {
  entries: HistorialEntry[];
}

export function HistorialAcciones({ entries }: HistorialAccionesProps) {
  if (entries.length === 0) {
    return (
      <div className="border-t border-border bg-card p-6">
        <h2 className="mb-4 text-lg font-bold text-foreground">
          Historial de acciones
        </h2>
        <p className="text-sm text-muted-foreground">
          No hay acciones registradas aún.
        </p>
      </div>
    );
  }

  return (
    <div className="border-t border-border bg-card p-6">
      <h2 className="mb-6 text-lg font-bold text-foreground">
        Historial de acciones
      </h2>

      <div className="space-y-0">
        {entries.map((entry, index) => (
          <div
            key={index}
            className={`flex gap-6 py-4 ${
              index < entries.length - 1 ? "border-b border-border" : ""
            }`}
          >
            {/* Timeline dot */}
            <div className="flex flex-col items-center">
              <div className="h-3 w-3 rounded-full bg-primary"></div>
              {index < entries.length - 1 && (
                <div className="mt-2 h-8 w-0.5 bg-border"></div>
              )}
            </div>

            {/* Content */}
            <div className="flex-1 pb-2">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                {entry.fecha}
              </p>
              <p className="mt-2 text-sm font-medium text-foreground">
                {entry.accion}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                Por: {entry.usuario}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
