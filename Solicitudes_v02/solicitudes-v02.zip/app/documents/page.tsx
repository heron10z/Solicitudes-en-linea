import { DocumentReview } from "@/components/documents/DocumentReview";

export const metadata = {
  title: "Revisión de Documentos - Sistema de Validación",
  description: "Revisar y validar documentos de solicitud",
};

export default function DocumentReviewPage() {
  // In a real app, these would come from URL params or an API
  const folio = "2025001234";
  const nombre = "María Elena Rodríguez Pérez";

  return <DocumentReview folio={folio} nombre={nombre} />;
}
