import { RequestDetail } from "@/components/detail/RequestDetail";

export default function DetailPage() {
  return <RequestDetail />;
}
