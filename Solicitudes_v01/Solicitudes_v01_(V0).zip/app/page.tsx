"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { StatusCards } from "@/components/status-cards"
import { FilterSection } from "@/components/filter-section"
import { RequestsTable } from "@/components/requests-table"

export type RequestStatus = "en_espera" | "notificada" | "validada" | "aceptada" | "rechazada"

export interface Request {
  folio: string
  nombre: string
  curp: string
  estatus: RequestStatus
  fechaUltimaAccion: string
}

const mockRequests: Request[] = [
  {
    folio: "EDU-2026-001234",
    nombre: "María Elena González Pérez",
    curp: "GOPM890512MDFRRL09",
    estatus: "en_espera",
    fechaUltimaAccion: "12/03/2026"
  },
  {
    folio: "EDU-2026-001235",
    nombre: "José Luis Hernández Ramírez",
    curp: "HERJ920315HDFRMS08",
    estatus: "notificada",
    fechaUltimaAccion: "11/03/2026"
  },
  {
    folio: "EDU-2026-001236",
    nombre: "Ana Patricia Martínez López",
    curp: "MALA880723MDFPRT02",
    estatus: "validada",
    fechaUltimaAccion: "10/03/2026"
  },
  {
    folio: "EDU-2026-001237",
    nombre: "Carlos Alberto Sánchez Díaz",
    curp: "SADC950108HDFRNS05",
    estatus: "aceptada",
    fechaUltimaAccion: "09/03/2026"
  },
  {
    folio: "EDU-2026-001238",
    nombre: "Rosa María Torres García",
    curp: "TOGR871230MDFRRS01",
    estatus: "rechazada",
    fechaUltimaAccion: "08/03/2026"
  },
  {
    folio: "EDU-2026-001239",
    nombre: "Fernando Ramírez Ortega",
    curp: "RAOF901115HDFMRR03",
    estatus: "en_espera",
    fechaUltimaAccion: "13/03/2026"
  },
  {
    folio: "EDU-2026-001240",
    nombre: "Guadalupe Flores Mendoza",
    curp: "FLMG850420MDFLRD07",
    estatus: "notificada",
    fechaUltimaAccion: "12/03/2026"
  },
  {
    folio: "EDU-2026-001241",
    nombre: "Roberto Carlos Vega Luna",
    curp: "VELR930805HDFGBR04",
    estatus: "validada",
    fechaUltimaAccion: "11/03/2026"
  }
]

export default function GestionSolicitudes() {
  const [activeFilter, setActiveFilter] = useState<RequestStatus | null>(null)
  const [searchFilters, setSearchFilters] = useState({
    folio: "",
    nombre: "",
    curp: "",
    estatus: ""
  })

  const statusCounts = {
    en_espera: mockRequests.filter(r => r.estatus === "en_espera").length,
    notificada: mockRequests.filter(r => r.estatus === "notificada").length,
    validada: mockRequests.filter(r => r.estatus === "validada").length,
    aceptada: mockRequests.filter(r => r.estatus === "aceptada").length,
    rechazada: mockRequests.filter(r => r.estatus === "rechazada").length
  }

  const filteredRequests = mockRequests.filter(request => {
    // Apply status card filter
    if (activeFilter && request.estatus !== activeFilter) return false
    
    // Apply search filters
    if (searchFilters.folio && !request.folio.toLowerCase().includes(searchFilters.folio.toLowerCase())) return false
    if (searchFilters.nombre && !request.nombre.toLowerCase().includes(searchFilters.nombre.toLowerCase())) return false
    if (searchFilters.curp && !request.curp.toLowerCase().includes(searchFilters.curp.toLowerCase())) return false
    if (searchFilters.estatus && request.estatus !== searchFilters.estatus) return false
    
    return true
  })

  const handleStatusCardClick = (status: RequestStatus) => {
    setActiveFilter(prev => prev === status ? null : status)
    setSearchFilters(prev => ({ ...prev, estatus: "" }))
  }

  const handleSearch = (filters: typeof searchFilters) => {
    setSearchFilters(filters)
    setActiveFilter(null)
  }

  const handleClearFilters = () => {
    setSearchFilters({ folio: "", nombre: "", curp: "", estatus: "" })
    setActiveFilter(null)
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="max-w-7xl mx-auto px-6 py-8">
        <h1 className="text-2xl font-semibold text-foreground mb-8">
          Gestión de Solicitudes
        </h1>

        <StatusCards 
          counts={statusCounts} 
          activeFilter={activeFilter}
          onStatusClick={handleStatusCardClick}
        />

        <FilterSection 
          filters={searchFilters}
          onSearch={handleSearch}
          onClear={handleClearFilters}
        />

        <RequestsTable requests={filteredRequests} />
      </main>
    </div>
  )
}
