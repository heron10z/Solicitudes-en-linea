"use client"

import { useState } from "react"
import { Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

interface FilterSectionProps {
  filters: {
    folio: string
    nombre: string
    curp: string
    estatus: string
  }
  onSearch: (filters: FilterSectionProps["filters"]) => void
  onClear: () => void
}

export function FilterSection({ filters, onSearch, onClear }: FilterSectionProps) {
  const [localFilters, setLocalFilters] = useState(filters)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSearch(localFilters)
  }

  const handleClear = () => {
    setLocalFilters({ folio: "", nombre: "", curp: "", estatus: "" })
    onClear()
  }

  const handleStatusChange = (value: string) => {
    setLocalFilters(prev => ({ ...prev, estatus: value === "todos" ? "" : value }))
  }

  return (
    <div className="bg-card border border-border rounded-md p-6 mb-8">
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div className="space-y-2">
            <label htmlFor="folio" className="text-sm font-medium text-foreground">
              Folio
            </label>
            <Input
              id="folio"
              placeholder="Ej: EDU-2026-001234"
              value={localFilters.folio}
              onChange={(e) => setLocalFilters(prev => ({ ...prev, folio: e.target.value }))}
              className="h-11"
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="nombre" className="text-sm font-medium text-foreground">
              Nombre
            </label>
            <Input
              id="nombre"
              placeholder="Nombre del aspirante"
              value={localFilters.nombre}
              onChange={(e) => setLocalFilters(prev => ({ ...prev, nombre: e.target.value }))}
              className="h-11"
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="curp" className="text-sm font-medium text-foreground">
              CURP
            </label>
            <Input
              id="curp"
              placeholder="Ej: GOPM890512MDFRRL09"
              value={localFilters.curp}
              onChange={(e) => setLocalFilters(prev => ({ ...prev, curp: e.target.value }))}
              className="h-11"
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="estatus" className="text-sm font-medium text-foreground">
              Estatus
            </label>
            <Select value={localFilters.estatus || "todos"} onValueChange={handleStatusChange}>
              <SelectTrigger id="estatus" className="h-11">
                <SelectValue placeholder="Seleccionar" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                <SelectItem value="en_espera">En espera</SelectItem>
                <SelectItem value="notificada">Notificada</SelectItem>
                <SelectItem value="validada">Validada</SelectItem>
                <SelectItem value="aceptada">Aceptada</SelectItem>
                <SelectItem value="rechazada">Rechazada</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-end gap-2">
            <Button 
              type="submit" 
              className="h-11 flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Search className="w-4 h-4 mr-2" />
              Buscar
            </Button>
            <Button 
              type="button" 
              variant="outline" 
              onClick={handleClear}
              className="h-11"
            >
              Limpiar
            </Button>
          </div>
        </div>
      </form>
    </div>
  )
}
