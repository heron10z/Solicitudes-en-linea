import { cn } from "@/lib/utils"
import type { RequestStatus } from "@/app/page"

interface StatusCardsProps {
  counts: Record<RequestStatus, number>
  activeFilter: RequestStatus | null
  onStatusClick: (status: RequestStatus) => void
}

const statusConfig: Record<RequestStatus, { label: string; borderColor: string; numberColor: string; bgActive: string }> = {
  en_espera: {
    label: "En espera",
    borderColor: "border-gray-300",
    numberColor: "text-primary",
    bgActive: "bg-gray-50"
  },
  notificada: {
    label: "Notificadas",
    borderColor: "border-blue-400",
    numberColor: "text-blue-600",
    bgActive: "bg-blue-50"
  },
  validada: {
    label: "Validadas",
    borderColor: "border-emerald-600",
    numberColor: "text-emerald-700",
    bgActive: "bg-emerald-50"
  },
  aceptada: {
    label: "Aceptadas",
    borderColor: "border-amber-500",
    numberColor: "text-amber-600",
    bgActive: "bg-amber-50"
  },
  rechazada: {
    label: "Rechazadas",
    borderColor: "border-gray-500",
    numberColor: "text-gray-600",
    bgActive: "bg-gray-100"
  }
}

export function StatusCards({ counts, activeFilter, onStatusClick }: StatusCardsProps) {
  const statuses: RequestStatus[] = ["en_espera", "notificada", "validada", "aceptada", "rechazada"]

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
      {statuses.map((status) => {
        const config = statusConfig[status]
        const isActive = activeFilter === status

        return (
          <button
            key={status}
            onClick={() => onStatusClick(status)}
            className={cn(
              "bg-card border-2 rounded-md p-5 text-left transition-all duration-150",
              "hover:shadow-md focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
              config.borderColor,
              isActive && config.bgActive,
              isActive && "ring-2 ring-primary ring-offset-2"
            )}
          >
            <p className={cn("text-4xl font-bold mb-1", config.numberColor)}>
              {counts[status]}
            </p>
            <p className="text-sm text-muted-foreground font-medium">
              {config.label}
            </p>
          </button>
        )
      })}
    </div>
  )
}
