import { cn } from "@/lib/utils"
import type { Request, RequestStatus } from "@/app/page"

interface RequestsTableProps {
  requests: Request[]
}

const statusLabels: Record<RequestStatus, { label: string; className: string }> = {
  en_espera: {
    label: "En espera",
    className: "bg-gray-100 text-gray-700 border-gray-300"
  },
  notificada: {
    label: "Notificada",
    className: "bg-blue-50 text-blue-700 border-blue-200"
  },
  validada: {
    label: "Validada",
    className: "bg-emerald-50 text-emerald-700 border-emerald-200"
  },
  aceptada: {
    label: "Aceptada",
    className: "bg-amber-50 text-amber-700 border-amber-200"
  },
  rechazada: {
    label: "Rechazada",
    className: "bg-gray-200 text-gray-600 border-gray-300"
  }
}

export function RequestsTable({ requests }: RequestsTableProps) {
  if (requests.length === 0) {
    return (
      <div className="bg-card border border-border rounded-md p-12 text-center">
        <p className="text-muted-foreground text-lg">
          No se encontraron solicitudes con los filtros aplicados.
        </p>
        <p className="text-muted-foreground text-sm mt-2">
          Intente modificar los criterios de búsqueda.
        </p>
      </div>
    )
  }

  return (
    <div className="bg-card border border-border rounded-md overflow-hidden">
      {/* Desktop Table */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-primary text-primary-foreground">
              <th className="text-left px-6 py-4 font-semibold text-sm">Folio</th>
              <th className="text-left px-6 py-4 font-semibold text-sm">Nombre del Aspirante</th>
              <th className="text-left px-6 py-4 font-semibold text-sm">CURP</th>
              <th className="text-left px-6 py-4 font-semibold text-sm">Estatus</th>
              <th className="text-left px-6 py-4 font-semibold text-sm">Fecha de última acción</th>
              <th className="text-left px-6 py-4 font-semibold text-sm">Acción</th>
            </tr>
          </thead>
          <tbody>
            {requests.map((request, index) => {
              const statusConfig = statusLabels[request.estatus]
              
              return (
                <tr 
                  key={request.folio}
                  className={cn(
                    "border-b border-border last:border-b-0 transition-colors",
                    index % 2 === 0 ? "bg-card" : "bg-muted/30",
                    "hover:bg-muted/50"
                  )}
                >
                  <td className="px-6 py-5 text-sm font-medium text-foreground">
                    {request.folio}
                  </td>
                  <td className="px-6 py-5 text-sm text-foreground">
                    {request.nombre}
                  </td>
                  <td className="px-6 py-5 text-sm text-foreground font-mono text-xs">
                    {request.curp}
                  </td>
                  <td className="px-6 py-5">
                    <span className={cn(
                      "inline-flex items-center px-3 py-1 rounded-sm text-xs font-medium border",
                      statusConfig.className
                    )}>
                      {statusConfig.label}
                    </span>
                  </td>
                  <td className="px-6 py-5 text-sm text-muted-foreground">
                    {request.fechaUltimaAccion}
                  </td>
                  <td className="px-6 py-5">
                    <button className="text-sm font-medium text-primary hover:text-primary/80 hover:underline transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 rounded px-2 py-1">
                      Revisar detalle
                    </button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden divide-y divide-border">
        {requests.map((request) => {
          const statusConfig = statusLabels[request.estatus]
          
          return (
            <div key={request.folio} className="p-5 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-foreground">{request.folio}</p>
                  <p className="text-sm text-foreground mt-1">{request.nombre}</p>
                </div>
                <span className={cn(
                  "inline-flex items-center px-3 py-1 rounded-sm text-xs font-medium border shrink-0",
                  statusConfig.className
                )}>
                  {statusConfig.label}
                </span>
              </div>
              
              <div className="space-y-1 text-sm">
                <p className="text-muted-foreground">
                  <span className="font-medium text-foreground">CURP:</span> {request.curp}
                </p>
                <p className="text-muted-foreground">
                  <span className="font-medium text-foreground">Última acción:</span> {request.fechaUltimaAccion}
                </p>
              </div>
              
              <button className="text-sm font-medium text-primary hover:text-primary/80 hover:underline transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 rounded px-2 py-1 -ml-2">
                Revisar detalle
              </button>
            </div>
          )
        })}
      </div>
    </div>
  )
}
