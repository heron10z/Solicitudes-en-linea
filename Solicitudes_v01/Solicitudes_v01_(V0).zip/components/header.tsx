import { User } from "lucide-react"

export function Header() {
  return (
    <header className="bg-card border-b border-border">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo and System Name */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              {/* Government Logo Placeholder */}
              <div className="w-12 h-12 bg-primary rounded-sm flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">MX</span>
              </div>
              <div className="hidden sm:block">
                <p className="text-xs text-muted-foreground uppercase tracking-wide">
                  Gobierno de México
                </p>
                <p className="text-sm font-medium text-foreground leading-tight">
                  Sistema de Validación de Solicitudes
                </p>
                <p className="text-sm font-medium text-foreground leading-tight">
                  de Educadores Comunitarios
                </p>
              </div>
            </div>
          </div>

          {/* User Profile */}
          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium text-foreground">Roberto García</p>
              <p className="text-xs text-muted-foreground">Validador</p>
            </div>
            <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center">
              <User className="w-5 h-5 text-muted-foreground" />
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
